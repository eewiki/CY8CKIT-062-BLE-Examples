/*******************************************************************************
* \file cy_ble_stack_gatt_server.h
* \version 2.0
*
* \brief
*  This file contains declarations of public BLE APIs of Generic Attribute Profile - Server Role.
*  Also specified the defines, constants, and data structures required for the APIs.
* 
* Related Document:
*  BLE Standard Spec - CoreV4.2, CSS, CSAs, ESR05, ESR06
* 
********************************************************************************
* \copyright
* Copyright 2014-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#ifndef CY_BLE__STACK_GATT_SERVER_H_
#define CY_BLE__STACK_GATT_SERVER_H_


/***************************************
* Common stack includes
***************************************/

#include "cy_ble_stack_gatt.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/***************************************
* GATT Server Constants
***************************************/
/**
 \addtogroup group_ble_common_api_gatt_definitions
 @{
*/

/***************************************
** Exported structures
***************************************/
/** Notification parameter */
typedef cy_stc_ble_gatt_write_param_t  cy_stc_ble_gatts_handle_value_ntf_t;

/** Indication parameter */
typedef cy_stc_ble_gatt_write_param_t  cy_stc_ble_gatts_handle_value_ind_t;

/* --------------------------Structure corresponding to events-------------------- */

/** Prepare write request parameter received from Client */
typedef struct
{
    /** Base address of the queue where data is queued. Queue is of type 
       cy_stc_ble_gatt_handle_value_offset_param_t. 
       Each baseAddr[currentPrepWriteReqCount-1].handleValuePair.value.val
       provides the current data and baseAddr[0].handleValuePair.value.val
       provides the base address of the data buffer where the full value will be stored.
       The application can calculate the total length based on each each array element;
       i.e., total length up current request = baseAddr[0].handleValuePair.value.len+
       ....+baseAddr[currentPrepWriteReqCount-1].handleValuePair.value.len
    */
    cy_stc_ble_gatt_handle_value_offset_param_t         * baseAddr;    

    /** Connection handle */
    cy_stc_ble_conn_handle_t                        connHandle;             

    /** Current count of prepare requests from remote. This parameter can be used 
       to access the data from 'baseAddr[]'. Array index will range from 0 to 
       currentPrepWriteReqCount - 1 */    
    uint8_t                                         currentPrepWriteReqCount;

    /** The application provides GATT error code for the procedure. This is an o/p parameter. */
    uint8_t                                         gattErrorCode;    

}cy_stc_ble_gatts_prep_write_req_param_t;

/** Execute Write result */
typedef struct
{
    /** Base address of the queue where data is queued. Queue is of type 
       cy_stc_ble_gatt_handle_value_offset_param_t. 
       baseAddr[0].handleValuePair.value.val
       provides the base address of the total data stored in the prepare write
       queue internally by the stack. 
       The application can calculate the total length based on each each array element;
       i.e., total length = baseAddr[0].handleValuePair.value.len+
       ....+baseAddr[prepWriteReqCount-1].handleValuePair.value.len
    */    
    cy_stc_ble_gatt_handle_value_offset_param_t     *baseAddr;

    /** Connection handle */
    cy_stc_ble_conn_handle_t                        connHandle; 

    /** Attribute Handle at which the error occurred. This is an o/p param.  */
    cy_ble_gatt_db_attr_handle_t                    attrHandle;     

    /** Total count of prepare requests from remote. This parameter can be used 
       to access the data from 'baseAddr[]'. The array index will range from 0 to 
       prepWriteReqCount - 1. */    
    uint8_t                                         prepWriteReqCount;

    /** Execute write flag received from remote */
    uint8_t                                         execWriteFlag;

    
    /** The application-provided GATT error code for the procedure. This is an o/p param. */
    uint8_t                                         gattErrorCode;

}cy_stc_ble_gatts_exec_write_req_t;

/** Write command request parameter received from Client */
typedef cy_stc_ble_gatt_write_param_t  cy_stc_ble_gatts_write_cmd_req_param_t;

/** Signed Write command request parameter received from Client */
typedef cy_stc_ble_gatt_write_param_t  cy_stc_ble_gatts_signed_write_cmd_req_param_t;

/** Event parameters for characteristic read value access
 * even generated by the BLE Stack upon an access of Characteristic value
 * read for the characteristic definition that  
 * CY_BLE_GATT_DB_ATTR_CHAR_VAL_RD_EVENT property set.
 **/
typedef struct
{
    /** Connection handle */
    cy_stc_ble_conn_handle_t             connHandle;

    /** Attribute Handle*/
    cy_ble_gatt_db_attr_handle_t     attrHandle;

    /** Output Param: Profile/Service specific error code,
         * profile or application need to change this 
         * to service specific error based on service/profile
         * requirements. */
    cy_en_ble_gatt_err_code_t           gattErrorCode;

}cy_stc_ble_gatts_char_val_read_req_t;
/** @} */

/***************************************
** Exported APIs
***************************************/
/**
 \addtogroup group_ble_common_api_gatt_server_functions
 @{
*/    

/******************************************************************************
* Function Name: Cy_BLE_GATTS_Notification
***************************************************************************//**
* 
*  This function sends a notification to the peer device when the GATT Server
*  is configured to notify a Characteristic Value to the GATT Client without
*  expecting any Attribute Protocol layer acknowledgment that the notification
*  was successfully received. This is a non-blocking function.
* 
*  On enabling notification successfully for a specific attribute, if the GATT server has an
*  updated value to be notified to the GATT Client, it sends out a 'Handle Value
*  Notification' which results in CY_BLE_EVT_GATTC_HANDLE_VALUE_NTF event at the
*  GATT Client's end.
* 
*  Refer to Bluetooth 4.1 core specification, Volume 3, Part G, section 4.10 for
*  more details on notifications.
*  
*  \param param: Pointer to a variable of type cy_stc_ble_gatts_handle_value_ntf_t.
*                   Where, the following needs to be set:
*                   param->handleValPair
*                   param->connHandle  
* 
* \return
*  cy_en_ble_api_result_t : Return value indicates whether the function succeeded or
*  failed. Following are the possible error codes.
* 
*  Error codes                           | Description
*  ------------                          | -----------
*   CY_BLE_SUCCESS                       | On successful operation.
*   CY_BLE_ERROR_INVALID_PARAMETER       | If 'param' is NULL or 'connHandle' is invalid or if 'param->handleValPair.value.len' value is greater than (Effective GATT MTU-3).
*   CY_BLE_ERROR_INVALID_OPERATION       | This operation is not permitted.
*   CY_BLE_ERROR_MEMORY_ALLOCATION_FAILED| Memory allocation failed.
*
*  \note
*  This operation is not permitted when the BLE Stack is busy processing previous requests. The 'CY_BLE_ERROR_INVALID_OPERATION'
*  error code will be returned if the stack queue is full or for other reasons, the stack cannot process the operation. If the stack
*  busy event 'CY_BLE_EVT_STACK_BUSY_STATUS' is triggered with status busy, calling this API will trigger this error code.
*  For details refer 'CY_BLE_EVT_STACK_BUSY_STATUS' event.
******************************************************************************/
cy_en_ble_api_result_t Cy_BLE_GATTS_Notification
(
    cy_stc_ble_gatts_handle_value_ntf_t * param
);


/******************************************************************************
* Function Name: Cy_BLE_GATTS_Indication
***************************************************************************//**
* 
*  This function sends an indication to the peer device when the GATT Server is
*  configured to indicate a Characteristic Value to the GATT Client and expects
*  an Attribute Protocol layer acknowledgment that the indication was 
*  successfully received. This is a non-blocking function.
* 
*  On enabling indication successfully, if the GATT server has an updated value to be 
*  indicated to the GATT Client, it sends out a 'Handle Value Indication' which
*  results in CY_BLE_EVT_GATTC_HANDLE_VALUE_IND event at the GATT Client's end.
* 
*  Refer to Bluetooth 4.1 core specification, Volume 3, Part G, section 4.11 for
*  more details on Indications.
* 
*  \param param: Pointer to a variable of type cy_stc_ble_gatts_handle_value_ind_t.
*                   Where, the following needs to be set:
*                   param->handleValPair
*                                 param->connHandle  
* 
* \return
*  cy_en_ble_api_result_t : Return value indicates whether the function succeeded or
*  failed. Following are the possible error codes.
*
*  Error codes                           | Description
*  ------------                          | -----------
*   CY_BLE_SUCCESS                       | On successful operation.
*   CY_BLE_ERROR_INVALID_PARAMETER       | If 'param' is NULL or 'connHandle' is invalid or if 'param->handleValPair.value.len' value is greater than (Effective GATT MTU-3).
*   CY_BLE_ERROR_INVALID_OPERATION       | This operation is not permitted.
*   CY_BLE_ERROR_MEMORY_ALLOCATION_FAILED| Memory allocation failed.
*
*  \note
*  This operation is not permitted when BLE Stack is busy processing previous requests. The 'CY_BLE_ERROR_INVALID_OPERATION'
*  error code will be returned if the stack queue is full or if, for other reasons, the stack cannot process the operation. If the stack
*  busy event 'CY_BLE_EVT_STACK_BUSY_STATUS' is triggered with status busy, calling this API will trigger this error code.
*  For details, refer to the 'CY_BLE_EVT_STACK_BUSY_STATUS' event.
*
******************************************************************************/
cy_en_ble_api_result_t Cy_BLE_GATTS_Indication
(
    cy_stc_ble_gatts_handle_value_ind_t * param
);


/******************************************************************************
* Function Name: Cy_BLE_GATTS_ErrorRsp
***************************************************************************//**
* 
*  This function sends an error response to the peer device. The Error Response
*  is used to state that a given request cannot be performed, and to provide the
*  reason as defined in 'cy_en_ble_gatt_err_code_t'. This is a non-blocking function.
* 
*  \note:'Write Command' initiated by GATT Client does not generate an
*  'Error Response' from the GATT Server's end. The GATT Client gets the
*  CY_BLE_EVT_GATTC_ERROR_RSP event on receiving an error response.
* 
*  Refer to the Bluetooth 4.1 core specification, Volume 3, Part F, section 3.4.1.1 for
*  more details on Error Response operation.
*  
*  \param param: Pointer to a variable of type cy_stc_ble_gatt_err_param_t.
*                     Where, the following needs to be set:
*                     param->opCode
*                                 param->connHandle  
*                     param->attrHandle
*                                 param->errorCode  
* 
* \return
*  cy_en_ble_api_result_t : Return value indicates whether the function succeeded or
*  failed. Following are the possible error codes.
*
*  Error codes                            | Description
*  ------------                           | -----------
*   CY_BLE_SUCCESS                        | On successful operation.
*   CY_BLE_ERROR_INVALID_PARAMETER        | If 'param' is NULL or 'connHandle' is invalid.
*   CY_BLE_ERROR_INVALID_OPERATION        | This operation is not permitted.
*   CY_BLE_ERROR_MEMORY_ALLOCATION_FAILED | Memory allocation failed.
* 
******************************************************************************/
cy_en_ble_api_result_t Cy_BLE_GATTS_ErrorRsp
(
    cy_stc_ble_gatt_err_param_t  * param
);


/******************************************************************************
* Function Name: Cy_BLE_GATTS_ExchangeMtuRsp
***************************************************************************//**
* 
* This function sends the GATT Server's GATT MTU size to the GATT Client. This
* function must be invoked in response to an Exchange GATT MTU Request received
* from the GATT Client. The GATT Server's GATT MTU size should be greater than or 
* equal to the default GATT MTU size (23 bytes). This is a non-blocking function.
* 
* The peer GATT Client receives CY_BLE_EVT_GATTC_XCHNG_MTU_RSP event on executing
* this function on the GATT Server.
* 
* Refer to Bluetooth 4.1 core specification, Volume 3, Part G, section 4.3.1 for
* more details on exchange of GATT MTU.
* 
*  \param param: parameter is of type CY_BLE_GATT_XCHG_MTU_REQ_PARAM_T.
*   param->mtu: Size of GATT MTU. Max GATT MTU supported by the BLE stack is 512 Bytes.
* 
* \return
*  cy_en_ble_api_result_t : Return value indicates whether the function succeeded or
*  failed. Following are the possible error codes.
*
*  Error codes                           | Description
*  ------------                          | -----------
*   CY_BLE_SUCCESS                       | On successful operation.
*   CY_BLE_ERROR_INVALID_PARAMETER       | If 'param' is NULL or 'connHandle' is invalid or 'mtu' value is greater than that set on calling Cy_BLE_StackInit().
*   CY_BLE_ERROR_INVALID_OPERATION       | This operation is not permitted.
*   CY_BLE_ERROR_MEMORY_ALLOCATION_FAILED| Memory allocation failed.
* 
******************************************************************************/
cy_en_ble_api_result_t Cy_BLE_GATTS_ExchangeMtuRsp
(
    cy_stc_ble_gatt_xchg_mtu_param_t  * param
);

 
/******************************************************************************
* Function Name: Cy_BLE_GATTS_WriteRsp
***************************************************************************//**
* 
*  This function sends a Write Response from a GATT Server to the GATT Client.
*  This is a non-blocking function. This function must be invoked in
*  response to a valid Write Request event from the GATT Client
*  (CY_BLE_EVT_GATTS_WRITE_REQ) to acknowledge that the attribute has been
*  successfully written.
* 
*  The Write Response must be sent after the attribute value is written or 
*  saved by the GATT Server. Write Response results in CY_BLE_EVT_GATTC_WRITE_RSP
*  event at the GATT Client's end.
* 
*  \param connHandle: Connection handle to identify the peer GATT entity, of type
             cy_stc_ble_conn_handle_t.
* 
* \return
*  cy_en_ble_api_result_t : Return value indicates whether the function succeeded or
*  failed. Following are the possible error codes.
*
*  Error codes                            | Description
*  ------------                           | -----------
*   CY_BLE_SUCCESS                        | On successful operation.
*   CY_BLE_ERROR_INVALID_PARAMETER        | If 'connHandle' is invalid.
*   CY_BLE_ERROR_INVALID_OPERATION        | This operation is not permitted.
*   CY_BLE_ERROR_MEMORY_ALLOCATION_FAILED | Memory allocation failed.
* 
******************************************************************************/
cy_en_ble_api_result_t Cy_BLE_GATTS_WriteRsp
(
    cy_stc_ble_conn_handle_t  connHandle
);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */
#endif /*CY_BLE__STACK_GATT_SERVER_H_*/


 /*EOF*/
