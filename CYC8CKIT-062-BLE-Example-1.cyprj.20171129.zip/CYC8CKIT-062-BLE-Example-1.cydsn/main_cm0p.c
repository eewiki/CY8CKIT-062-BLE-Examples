#include "project.h"
#include "BLE_applications.h"
#include "I2C_1.h"
 
int main(void)
{
    __enable_irq(); /* Enable global interrupts. */
    
    /* Disable the Watchdog Timer to avoid CPU resets */
    Cy_WDT_Unlock();
    Cy_WDT_Disable();    
    
    I2C_1_Start();
 
    /* Start BLE component and register the customEventHandler function. This 
	   function exposes the events from BLE component for application use */
    Cy_BLE_Start(customEventHandler);
 
    for(;;)
    {
        /* Process event callback to handle BLE events. The events generated 
		   and used for this application are inside the 'customEventHandler' 
           routine */
        Cy_BLE_ProcessEvents();
        
        /* Start the BLE advertisement if required */
        startAdvertisement();        
    }
}